let name = "Mithilesh Ranjan";

  console.log(name);

name = "Shiv Shankar Prasad";

  console.log(name);

name = "Belwanti Devi";

  console.log(name);