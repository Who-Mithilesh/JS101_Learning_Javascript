const name = "👉 Mⷨiͥᴛⷮhͪiͥleͤs͛hͪ Rͬaͣnjaͣn 👈\n";
const school = "🏪 S͛rͬiͥ S͛aͣiͥ Iͥnᴛⷮeͤrͬnaͣᴛⷮiͥoͦnaͣl S͛cͨhͪoͦoͦl 🏪\n";
const grade = "📚 🅰+ 📚\n";
let section = "🏤 🅱 🏤\n";
let rollno = "📌 ➊➎ 📌\n";
const scienceMarks = "📔 8͓͕͜2̢̠̻ 📔\n";
const mathsMarks = "📓 8͚͖4̦͓ 📓\n";
const englishMarks = "📒 7͇͚͎6̞̪̝ 📒\n";

  console.log(name,school,grade,section,rollno,scienceMarks,mathsMarks,englishMarks);