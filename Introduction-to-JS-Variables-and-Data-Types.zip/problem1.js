console.log("Masai School");
console.log("A Transformation in Education");