// Given 3 numbers (all different values), print which is greatest

let num1 = 17, num2 = 15, num3 = 5;

// if(num1 > num2 && num1 > num3){
//   console.log(num1, "is greater.");
// }else if(num2 > num1 && num2 > num3){
//   console.log(num2, "is greater.");
// }else{
//   console.log(num3, "is greater.");
// }

(num1 > num2 && num1 > num3) ? console.log(num1, "is greater.") : (num2 > num1 && num2 > num3) ? console.log(num2, "is greater.") : console.log(num3, "is greater.");