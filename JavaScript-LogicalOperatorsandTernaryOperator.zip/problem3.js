// Given and character if it is a consonant print "Consonant"

let ch = "b";

(ch != "a" || ch != "e" || ch != "i" || ch != "o" || ch != "u") ? console.log("Consonant"): console.log("Vowel");