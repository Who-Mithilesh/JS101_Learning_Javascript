// Given any character, if it is a vowel print "Vowel"

let ch = "i";

(ch == "a" || ch == "e" || ch == "i" || ch == "o" || ch == "u") ? console.log("Vowel"): console.log("Consonant");