
let x = 9112;
let y = 10;
let z = "Aman";
  console.log(x + y + z);