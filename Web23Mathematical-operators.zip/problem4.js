let x = 27;

console.log(x ** 0.33);