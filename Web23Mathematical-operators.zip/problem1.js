//given 
let a = 3;
let b = 2;

console.log("Sum is", a+b);
console.log("Sub is", a-b);
console.log("mult is", a*b);
console.log("div is", a/b);