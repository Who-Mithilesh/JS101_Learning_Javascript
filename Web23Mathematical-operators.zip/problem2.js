// Calculate the square root of x.

let x = 200;

console.log(x ** .5);