let $a = 10;
let _a = 20;
console.log($a);
console.log(_a);